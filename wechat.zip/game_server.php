<?php
/**
 * Description:
 * Type:
 * User: NEW_WORLD
 * Date: 2017/7/15
 * Time: 19:30
 */

//创建websocket服务器对象，监听0.0.0.0:9502端口
$ws = new swoole_websocket_server("0.0.0.0", 9502);
$client_list = array();
//监听WebSocket连接打开事件
$ws->on('open', function ($ws, $request) {
    echo "{$request->fd} link\n";
    //告知其他客户端
    global $client_list;
    foreach ($client_list as $key => $value) {
        $data = array('type' => '上线',
            'data' => array('nickename'=>'昵称','time'=>time())
        );
        $ws->push($request->fd, json_encode($data));
    }
    //保存客户端信息
    $client_list[$request->fd] = $request->fd;
    //向客户端问好
    $data = array('who' => '官方', 'msg' => '少年你来了?', 'time' => time());
    $ws->push($request->fd, json_encode($data));
});

//监听WebSocket消息事件
$ws->on('message', function ($ws, $frame) {
    echo "{$frame->fd} 客户端发来了消息\n";
    global $client_list;
    echo "内容: {$frame->data}\n";
    //广播客户端的消息

    foreach ($client_list as $key => $client) {
        $data = array('who' => $client, 'msg' => $frame->data, 'time' => time());
        $ws->push($key, json_encode($data));
    }


});

//监听WebSocket连接关闭事件
$ws->on('close', function ($ws, $fd) {
    global $client_list;
    unset($client_list[$fd]);
    echo "$fd closed\n";
    //广播断线消息
    foreach ($client_list as $key => $value) {
        $data = array('who' => '官方', 'msg' => "{$fd} 离线了\n", 'time' => time());
        $ws->push($key, json_encode($data));
    }

});

$ws->start();




